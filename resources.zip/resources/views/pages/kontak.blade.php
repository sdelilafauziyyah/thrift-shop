@extends('layouts.about')

@section('title')
Store Dashboard
@endsection

@section('content')
<!-- Section Content -->
        <div
        class="section-content section-dashboard-home"
        data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
            <h2 class="dashboard-title">About</h2>
            <p class="dashboard-subtitle">
                Contact
            </p>
            </div>
            <div class="dashboard-content">
            <div class="row">
                <div class="col-12">
                  <img src="/images/banner.jpg" class="w-75" alt="">
                </div>
            </div>
            
            </div>
        </div>
        </div>
@endsection